package AppiumDemoGroup.SeleniumJava;

import java.net.MalformedURLException;
import java.net.URL;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;


public class AppTest {
	
	public AppiumDriver<IOSElement> driver;
	
	@Before
	public void setup() throws MalformedURLException {
		
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("platformVersion", "11.0");
		capabilities.setCapability("deviceName", "iPad Air");
		capabilities.setCapability("platformName", "iOS");
		capabilities.setCapability("app", "/Users/lantony/Documents/ManiAppiumFiles/LsCompMani.ipa");
		capabilities.setCapability("noReset", "true");
		
		driver = new IOSDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

	}
	
	public void tearDown()
	{
		driver.quit();
	}
	
	@Test
	public void lsComplianceSampleTest()
	{
		IOSElement userIdText = driver.findElement(By.xpath("//XCUIElementTypeTextField[@value='Network ID']"));
		userIdText.sendKeys("lantony");
		//(//XCUIElementTypeOther[@name="Starbucks Licensed Stores Non-Compliance App WELCOME Network ID Network Password Log In "])[2]/XCUIElementTypeTextField
		//Network ID
		////XCUIElementTypeOther[@name="Network Password "]/XCUIElementTypeSecureTextField
		//Network Password
		//Log In
		IOSElement passwordText = driver.findElement(By.xpath("//XCUIElementTypeOther[@name='Network Password ']/XCUIElementTypeSecureTextField"));
		passwordText.sendKeys("test@888");
		IOSElement button = driver.findElement(By.xpath("//XCUIElementTypeStaticText[@name='Log In']"));
		button.click();
		button.click();
	}
}











